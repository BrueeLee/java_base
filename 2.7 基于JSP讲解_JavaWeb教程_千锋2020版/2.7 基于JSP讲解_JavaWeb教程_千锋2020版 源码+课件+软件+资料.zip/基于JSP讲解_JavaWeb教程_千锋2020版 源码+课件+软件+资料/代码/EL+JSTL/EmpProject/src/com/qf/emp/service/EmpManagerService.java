package com.qf.emp.service;

import com.qf.emp.entity.EmpManager;

public interface EmpManagerService {
    public EmpManager login(String username,String password);
}
