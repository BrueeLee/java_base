package com.qf.emp.utils;

import com.qf.emp.dao.EmpDao;
import com.qf.emp.dao.impl.EmpDaoImpl;
import com.qf.emp.entity.Emp;
import com.qf.emp.entity.Page;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        EmpDao empDao = new EmpDaoImpl();
        Page page = new Page(2);

        List<Emp> empList = empDao.selectAll(page);

        for (Emp emp : empList) {

            System.out.println(emp);
        }
    }
}
